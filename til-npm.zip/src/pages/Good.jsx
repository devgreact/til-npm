function Good() {
  return <div>Good</div>;
}
export default Good;
