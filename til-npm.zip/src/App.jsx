import Counter from "./components/Counter";
import Todo from "./components/Todo";

function App() {
  return (
    <div>
      <Counter />
      <Todo />
    </div>
  );
}
export default App;
