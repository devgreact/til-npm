const companyRouter = () => {
  return [
    { path: "ceo", element: <h1>회장님인사말</h1> },
    { path: "location", element: <h1>회사위치</h1> },
  ];
};
export default companyRouter;
